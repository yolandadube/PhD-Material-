# This code uses : (1) the single tracer power spectrum monopole
#				   (2) the MCMC to detect the turnover in the monopole
#                  (3) a 4-parameter model for the monopole; [P0, k0, \alpha, \beta]
#--------------------------------------------------------------------------------------------------------------------------

import glob
import time
import os, sys
import numpy as np
from natsort import natsorted
#--------------------------------------------------------------------------------------------------------------------------

# main path directory
mainPath = "/home/sheean3/Documents/cosmologicalCode/mcmc/version1/"
#--------------------------------------------------------------------------------------------------------------------------

# import functions
sys.path.append(mainPath+"functions/planckBestFit/")
sys.path.append(mainPath+"functions/pyCLASSWrapper/")
#sys.path.append(mainPath+"functions/surveyRedshifts/")
sys.path.append(mainPath+"functions/markovChainMonteCarlo/")
#---#
from MCMC import mcmcAlgorithm
from compileCLASS import pyCompileCLASS
#from surveyRedshiftRange import redshiftRange
from planckCosmologicalParameters import planckValues
#--------------------------------------------------------------------------------------------------------------------------

# compile CLASS
compilation = pyCompileCLASS(mainPath)
#--------------------------------------------------------------------------------------------------------------------------

# dictionary fiducial Planck cosmological parameters
dictionary    = {'H0'         :67.66,     # hubble parameter today
				 'omb'        :0.02242,   # physical omega baryonic today, \omega_b = \Omega_b0 * h^{2} 
				 'omcdm'      :0.11933,   # physical omega cold dark matter today, \omega_cdm = \Omega_cdm0 * h^{2}
				 'omega_k0'   :0.0,       # omega curvature today
				 'omega_n0'   :0.0,       # omega neutrino today
				 'n_s'        :0.9665,    # spectral index of primordial power spectrum
				 'A_s'        :2.105e-09, # A_s 
				 'sigma80'    :0.8102,    # sigma_8 today
				 'gamma'      :0.55,      # linear growth index
				 'w'          :-1.0,      # equation of state parameter for dark energy
				 'fnl'        :0.0        # primordial non-Gassianity parameter
				}
PlanckData = planckValues(dictionary)
#--------------------------------------------------------------------------------------------------------------------------

# gauge of perturbations: 'newtonian' or 'synchronous'
gauge      = 'synchronous'
#--------------------------------------------------------------------------------------------------------------------------

# 1st order contributions in the source number count fluctuations
NewtonianO1 = True
#--------------------------------------------------------------------------------------------------------------------------

# MCMC parameters list
mcmcParameters  = ['p0', 'k0', 'alpha', 'beta']

# priors for MCMC parameters
priors          = {'p0'    :[1.0e+03, 1.0e+06],
				   'k0'    :[5.0e-03, 5.0e-02], 
				   'alpha' :[-3.0, 5.0],
				   'beta'  :[-0.5, 0.5]    
		    	  }
#--------------------------------------------------------------------------------------------------------------------------

# number of Markov chains
chains     = 50

# maximum number of walks per Markov chain
walks      = 10000
#--------------------------------------------------------------------------------------------------------------------------

# type of surveys: "galaxy" or "HI IM"
survey1 = "HI IM"
survey2 = "HI IM"
surveys = [survey1, survey2]

# mode of survey: "single dish" or "interferometer"
modeSurvey1 = "single dish"
modeSurvey2 = "single dish"
modeSurveys = [modeSurvey1, modeSurvey2]

# specifications of survey: 
# GALAXY:                 : "HAlpha", "desiBGS", "desiELG",
#							"skaOGalBand2", "megaMapLBG"
# HI IM                   : "skaOIMBand1", "skaOIMBand2", 
#							"meerKATLBand", "meerKATUHFBand", "dsa2000",  
#							"hirax256", "hirax1024", "puma5k", 'puma32k'
specsSurvey1     = "skaOIMBand1"
specsSurvey2     = "skaOIMBand1"
specsSurveys     = [specsSurvey1, specsSurvey2]
#--------------------------------------------------------------------------------------------------------------------------

# modelling the surveys + systematics

# fingers-of-God effect
fingerOfGod = False
# foreground effect
foreGround  = True
# beam effect
beam        = True
# non-linear cut-off [h Mpc^{-1}]
k_NL0       = 0.08 
# foreground scale cut-off [h Mpc^{-1}]
k_fg        = 0.005
# wedge parameter (Nwedge = 0, 1, 3)
Nwedge      = 1.0
# do non-linear matter power spectrum
nonLinear   = False
#--------------------------------------------------------------------------------------------------------------------------

# redshift bin size
delta_z          = 0.1

# redshift bin centre
z                = np.array([1.0])

# generate the array of k
kMin, kMax       = [6.0e-03, 4.0e-02]
k                = np.linspace(kMin, kMax, 700, endpoint=True)
#--------------------------------------------------------------------------------------------------------------------------

# run the MCMC code
start       = time.time()
runMCMC     = mcmcAlgorithm(mainPath, mcmcParameters, priors, chains, walks, PlanckData, gauge, nonLinear, k, \
							k_NL0, k_fg, Nwedge, z, delta_z, dictionary, surveys, specsSurveys, modeSurveys, \
							fingerOfGod, foreGround, beam, NewtonianO1)
end         = time.time()
timeTaken   = end-start
if (timeTaken>60.0):
	print("run time = %.1f min"%((end-start)/60.0))
else:
	print("run time = %.1f s"%(end-start))
#--------------------------------------------------------------------------------------------------------------------------