def latexDictionary(mcmcParameter):

	# mcmcParameter  ---> parameter name

	# parameter labels
	dictionary = {'p0'    :r'$P_{0}\,\big[h^{-3}\,\mathrm{Mpc}^{3}\big]$',
				  'k0'    :r'$k_{0}\,\big[h\,\mathrm{Mpc}^{-1}\big]$', 
				  'alpha' :r'$\alpha$', 
				  'beta'  :r'$\beta$'
				 }

	return dictionary[mcmcParameter]
#----------------------------------------------------------------------