# sky temperature in K, arXiv: 1810.09572
def T_sky(z):

	# frequency of 21 cm emission in MHz
	nu21 = 1420.0

	term1 = 2.7
	term2 = 25.0*( (400.0/nu21)*(1.0+z) )**2.75

	return term1+term2
#----------------------------------------------------------------------