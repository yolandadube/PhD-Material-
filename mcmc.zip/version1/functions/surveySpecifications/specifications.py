# importing packages
import numpy as np
#----------------------------------------------------------------------

def surveySpecs(specsSurvey):

	# HAlpha
	if (specsSurvey=="HAlpha"):
		# number of dishes
		N_dish            = 0.0
		# diameter of dishes in m
		D_dish            = 0.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 15.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 0.0
		# diameter of receiving area in m
		D_res             = D_dish

	# DESI BGS
	if (specsSurvey=="desiBGS"):
		# number of dishes
		N_dish            = 0.0
		# diameter of dishes in m
		D_dish            = 0.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 14.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 0.0
		# diameter of receiving area in m
		D_res             = D_dish

	# DESI ELG
	if (specsSurvey=="desiELG"):
		# number of dishes
		N_dish            = 0.0
		# diameter of dishes in m
		D_dish            = 0.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 14.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 0.0
		# diameter of receiving area in m
		D_res             = D_dish

	# skaO Gal. Band2
	if (specsSurvey=="skaOGalBand2"):
		# number of dishes
		N_dish            = 0.0
		# diameter of dishes in m
		D_dish            = 0.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 5.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 0.0
		# diameter of receiving area in m
		D_res             = D_dish

	# MegaMapper LBG
	if (specsSurvey=="megaMapLBG"):
		# number of dishes
		N_dish            = 0.0
		# diameter of dishes in m
		D_dish            = 0.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 14.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 0.0
		# diameter of receiving area in m
		D_res             = D_dish

	# skaO IM Band 1
	if (specsSurvey=="skaOIMBand1"):
		# number of dishes
		N_dish            = 197.0
		# diameter of dishes in m
		D_dish            = 15.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 20.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 10.0e+03
		# diameter of receiving area in m
		D_res             = D_dish

	# skaO IM Band 2
	if (specsSurvey=="skaOIMBand2"):
		# number of dishes
		N_dish            = 197.0
		# diameter of dishes in m
		D_dish            = 15.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 20.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 10.0e+03
		# diameter of receiving area in m
		D_res             = D_dish

	# hirax256
	if (specsSurvey=="hirax256"):
		# number of dishes
		N_dish            = 256.0
		# diameter of dishes in m
		D_dish            = 6.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 15.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 17.5e+03
		# diameter of receiving area in m
		D_res             = 141.0

	# hirax1024
	if (specsSurvey=="hirax1024"):
		# number of dishes
		N_dish            = 1024.0
		# diameter of dishes in m
		D_dish            = 6.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 15.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 17.5e+03
		# diameter of receiving area in m
		D_res             = 282.0

	# meerKAT L Band
	if (specsSurvey=="meerKATLBand"):
		# number of dishes
		N_dish            = 64.0
		# diameter of dishes in m
		D_dish            = 13.5
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# fraction of sky covered
		f_sky             = 0.10
		# survey sky area in square degrees
		survey_area_sky   = f_sky * total_area_of_sky
		# total observation time in h
		t_total           = 4.0e+03
		# diameter of receiving area in m
		D_res             = D_dish

	# meerKAT UHF Band
	if (specsSurvey=="meerKATUHFBand"):
		# number of dishes
		N_dish            = 64.0
		# diameter of dishes in m
		D_dish            = 13.5
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# fraction of sky covered
		f_sky             = 0.10
		# survey sky area in square degrees
		survey_area_sky   = f_sky * total_area_of_sky
		# total observation time in h
		t_total           = 4.0e+03
		# diameter of receiving area in m
		D_res             = D_dish
	'''
	# chime
	if (specsSurvey=="chime"):
		# number of dishes
		N_dish            = 1024.0
		# diameter of dishes in m
		D_dish            = 20.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# fraction of sky covered
		f_sky             = 0.60
		# survey sky area in square degrees
		survey_area_sky   = f_sky * total_area_of_sky
		# total observation time in h
		t_total           = 10.0*10.0**(3.0)
	'''
	# puma5k 
	if (specsSurvey=="puma5k"):
		# number of dishes
		N_dish            = 5000.0
		# diameter of dishes in m
		D_dish            = 6.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 20.6e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 40.0e+03
		# diameter of receiving area in m
		D_res             = 648.0

	# puma32k
	if (specsSurvey=="puma32k"):
		# number of dishes
		N_dish            = 32000.0
		# diameter of dishes in m
		D_dish            = 6.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 20.6e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 40.0e+03
		# diameter of receiving area in m
		D_res             = 1640.0

	# DSA2000
	if (specsSurvey=="dsa2000"):
		# number of dishes
		N_dish            = 2000.0
		# diameter of dishes in m
		D_dish            = 5.0
		# total area of sky in square degrees
		total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
		# survey sky area in square degrees
		survey_area_sky   = 30.0e+03
		# fraction of sky covered
		f_sky             = survey_area_sky/total_area_of_sky
		# total observation time in h
		t_total           = 43.8e+03
		# diameter of receiving area in m
		D_res             = 15300.0

	return N_dish, D_dish, survey_area_sky, t_total, D_res
#----------------------------------------------------------------------