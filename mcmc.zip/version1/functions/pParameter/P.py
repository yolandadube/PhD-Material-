def p(survey):

	if(survey=="galaxy"):
		pTerm = 0.55

	if(survey=="HI IM"):
		pTerm = 1.25

	return pTerm
#----------------------------------------------------------------------