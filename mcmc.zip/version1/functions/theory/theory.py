import numpy as np
#----------------------------------------------------------------------

def model(k, P0, k0, alpha, beta):

	# we follow arXiv: 2202.13828
	# the model is a fit for the monopole of the power spectrum
	# the fit is done around the turnover of the power spectrum

	# the fit is assumed to be a parabolic curve, which is 
	# asymmetric around the turnover scale k0

	# alpha, beta: parameters that regulate the shape of 
	#			   the parabola
	
	# P0: monopole amplitude around turnover for the fit

	# fitting formula 
	x    = (k/k0) - 1.0
	fit  = np.where( k<k0, pow(P0, (1.0 - (alpha*x**2.0))), pow(P0, (1.0 - (beta*x**2.0))) )

	return fit
#----------------------------------------------------------------------