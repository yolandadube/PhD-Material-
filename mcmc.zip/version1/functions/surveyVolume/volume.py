# importing packages
import os, sys
import numpy as np
from scipy import interpolate
#----------------------------------------------------------------------

def comovingV(mainPath, z, delta_z, cosmologY, specsSurvey): 

	sys.path.append(mainPath+"functions/backgroundCosmology/")
	sys.path.append(mainPath+"functions/surveySpecifications/")
	# importing functions
	from specifications import surveySpecs
	from comovingDistance import comoving_distance
	#---#
	# lower limit
	z_min = z-(delta_z/2.0)
	# upper limit
	z_max = z+(delta_z/2.0)
	# survey specifications
	survey_area_sky   = surveySpecs(specsSurvey)[2]
	# total area of sky in square degrees
	total_area_of_sky = 4.0*np.pi*(180.0/np.pi)**2.0
	# fraction of sky covered
	f_sky    = survey_area_sky/total_area_of_sky
	
	# comoving volume in h^{-3} Mpc^{3}
	chi_zmin = comoving_distance(z_min, cosmologY)
	chi_zmax = comoving_distance(z_max, cosmologY)
	V        = ( (4.0*np.pi*f_sky)/3.0 ) * ( chi_zmax**3.0 - chi_zmin**3.0 )
	
	return V
#----------------------------------------------------------------------