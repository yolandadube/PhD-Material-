# importing packages
import sys, os
import numpy as np
#----------------------------------------------------------------------

def Nmodes(mainPath, k, z, delta_z, cosmologY, surveys, specsSurveys, modeSurveys):

	sys.path.append(mainPath+"functions/surveyVolume/")
	#---#
	from volume import comovingV
	#--#

	# surveys
	survey1, survey2           = surveys
	modeSurvey1, modeSurvey2   = modeSurveys
	specsSurvey1, specsSurvey2 = specsSurveys

	# survey volume
	Vs      = comovingV(mainPath, z, delta_z, cosmologY, specsSurvey1)

	# fundamental mode [h Mpc^{-1}]
	kf      = (2.0*np.pi) / Vs**(1.0/3.0)

	# k-bin width 
	delta_k = kf

	# N_modes [arXiv: 2209.07595]
	N_modes = (Vs * k**2.0*delta_k) / (4.0*np.pi**2.0)

	return N_modes
#----------------------------------------------------------------------